# Directory contents:

* A *downloads* folder that contains starter project files that are zipped for easy download and extraction.
* A *labs* folder that contains the uncompressed versions of the starter files

>**Note:** not all exercises have starter files. 